import React, { useState } from 'react'
import Header from '../Common/Header'
import Footer from '../Common/Footer'
import { Link } from 'react-router-dom'
import { Form, FormControl, InputGroup } from 'react-bootstrap'
const Claimform = () => {
    return (
        <div>
            <Header />
            <section className="page-header">
                <div className="page-header-bg"></div>
                <div className="container">
                    <div className="page-header__inner">
                        <div className="innerbanner">
                            <h4 className="text-custom-white no-margin">Claim Form</h4>
                        </div>
                        <h6 className='para_absdasa'>Best quotes for you !!!</h6>
                    </div>
                </div>
            </section>
            <div className='myprofile'>
                <div className='container myprofile1 pt-4 pb-4'>
                    <div className='row' style={{ justifyContent: 'center' }}>
                        <div className='col-lg-3 col-md-12 col-sm-12 col-xs-12'>
                            <div className="sidebar">
                                <Link to="/Mypolicies">
                                    My Policies <span>(2)</span>
                                </Link>
                                <Link to="/Pendingpolicies">Pending Policies<span>(1)</span></Link>
                                <Link to="/Policiesrenewal">Renewal <span>(1)</span></Link>
                                <Link to="/Claimlist" className="active">My Claim <span>(3)</span></Link>
                                <Link to="">Special Offer <span>(4)</span></Link>
                                <Link to="/Myprofile">My Profile</Link>
                                <Link to="">Logout</Link>
                            </div>
                        </div>
                        <div className='col-lg-9 col-md-12 col-sm-12 col-xs-12'>
                            <div className='my_profile'>
                            <div className='col-lg-12'>
                                    <InputGroup className="mb-4">
                                        <Form.Control required
                                            placeholder="Policy Number"
                                            aria-label="Policy Number"
                                        />
                                    </InputGroup>
                                </div>
                                <div className='col-lg-12'>
                                    <InputGroup className="mb-4">
                                        <Form.Control required
                                            placeholder="Full Name"
                                            aria-label="Full Name"
                                        />
                                    </InputGroup>
                                </div>
                                <div className='col-lg-12'>
                                    <InputGroup className="mb-4">
                                        <Form.Control required
                                            placeholder="Email ID"
                                            aria-label="Email ID"
                                        />
                                    </InputGroup>
                                </div>
                                <div className='col-lg-12'>
                                    <InputGroup className="mb-4">
                                        <InputGroup.Text id="basic-addon1"><i class="fa fa-phone" aria-hidden="true"></i>
                                        </InputGroup.Text>
                                        <Form.Control required
                                            placeholder="Phone Number"
                                            aria-label="Phone Number"
                                        />
                                    </InputGroup>
                                </div>
                                <div className='col-lg-12'>
                                    <InputGroup className="mb-4">
                                        <FormControl placeholderText={'Please select a date'} type='file' />
                                    </InputGroup>
                                </div>
                                <div className='col-lg-12'>
                                    <InputGroup className="mb-4">
                                        <textarea placeholder='Type Your Information Here...... (Optional)' className='form-control' rows="5"></textarea>
                                    </InputGroup>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Footer />
        </div>
    )
}

export default Claimform