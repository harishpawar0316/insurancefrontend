import { initializeApp } from "firebase/app";
import { getDatabase, push, ref, set } from "firebase/database";
import { v4 as uuidv4 } from 'uuid';
console.log(process.env)
const firebaseConfig = {
    apiKey: process.env.REACT_APP_APIKEY,
    authDomain: process.env.REACT_APP_AUTHDOMAIN,
    projectId: process.env.REACT_APP_PROJECTID,
    storageBucket: process.env.storageBucket,
    messagingSenderId: process.env.REACT_APP_MESSAGINGSENDERID,
    appId: process.env.REACT_APP_STORAGEBUCKET,
    databaseURL:process.env.REACT_APP_DATABASEURL
  };

export   const generateSessionId = () => {
  const sessionId = uuidv4(); 
  return sessionId;
  };
 export const firebaseapp = initializeApp(firebaseConfig);
 export const database = getDatabase(firebaseapp);
 export   const sendRoomId = async (Roomid) => {
  try {
    await set(ref(database, `roomIds/${Roomid}`), { Roomid });
    console.log('Roomid added to Firebase collection successfully');
  } catch (error) {
    console.error("Error", error);
  }
};
export  const PostChatmessage=async(newMessage,Roomid)=>{
  // Save the new message to Firebase Realtime Database
  push(ref(database, `chat/${Roomid}`), newMessage);
 }